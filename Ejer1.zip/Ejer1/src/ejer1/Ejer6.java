import java.util.HashMap;
import java.util.Scanner;

public class Ejer6 {
    public static void main(String[] args) {
        HashMap<String, String> usuarios = new HashMap<>();
        usuarios.put("jose", "1234");
        usuarios.put("jose1", "abcd");

        Scanner sc = new Scanner(System.in);
        int intentos = 3;
        boolean acceso = false;

        while (intentos > 0 && !acceso) {
            String u = sc.nextLine();
            String p = sc.nextLine();
            if (usuarios.containsKey(u) && usuarios.get(u).equals(p)) acceso = true;
            else intentos--;
        }
        System.out.println(acceso ? "Acceso completo" : "Denegado");
    }
}
