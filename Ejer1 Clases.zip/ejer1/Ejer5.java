import java.util.ArrayList;

class Disco {
    String titulo;
    Disco(String t) { titulo = t; }
    public String toString() { return titulo; }
}

public class Ejer5 {
    public static void main(String[] args) {
        ArrayList<Disco> discos = new ArrayList<>();
        discos.add(new Disco("Colores"));
        discos.add(new Disco("Oasis"));
        discos.add(new Disco("Jose"));
        for (Disco d : discos) System.out.println(d);
    }
}