import java.util.ArrayList;

public class Ejer1 {
    public static void main(String[] args) {
        ArrayList<String> nombres = new ArrayList<>();
        nombres.add("Carlos");
        nombres.add("Lucia");
        nombres.add("Mario");
        nombres.add("Elena");
        nombres.add("Javier");
        nombres.add("Sofia");

        for (String nombre : nombres) {
            System.out.println(nombre);
        }
    }
}
